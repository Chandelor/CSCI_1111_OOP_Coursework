/*
 * Author: Chandelor Losee
 * Date: 1/30/23
 * 
 * Reads a string and outputs how many characters and letters it has.
 */
import java.util.Scanner;
public class Exercise_6_20 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String s = input.nextLine();
		System.out.println("\'" + s + "\'" + " is " + s.length() + " characters long");
		System.out.println("There are " + countLetters(s) + " letters in " + "\'" + s + "\'");
	}

	public static int countLetters(String s) {
		
		int l = 0;
		for (int n = 0; n < s.length();n++) {
			for (char m = 'A'; m < 'z'; m++) {
				if (s.charAt(n) == m) {
					l++;
				}
				
			}
			
		}
		
		return l;
	}
	
}

