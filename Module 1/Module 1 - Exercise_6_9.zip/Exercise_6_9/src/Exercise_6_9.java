/*
 * Author: Chandelor Losee
 * Date: 1/27/23
 * 
 * Converts and prints Feet to Meters.
 * Converts and prints Meters to Feet.
 */

public class Exercise_6_9 {

	public static void main(String[] args) {
		
		double f = 1;
		double m = 20;
		System.out.println("Feet     Meters          Feet      Meters");
		System.out.println("------------------------------------------");
		
		for (int n = 0; n < 10; n++, f++, m += 5) {
			System.out.printf("%-8.1f %-15.3f %-9.1f %-6.3f \n", f, Conversion.feetToMeters(f), m, Conversion.metersToFeet(m));
		}
		
	}
	
}

class Conversion {

	/** Convert from feet to meters */
	public static double metersToFeet(double meters) {
		return 3.279 * meters;
	}

	/** Convert from meters to feet */
	public static double feetToMeters(double feet) {
		return 0.305 * feet;
	}
	
}