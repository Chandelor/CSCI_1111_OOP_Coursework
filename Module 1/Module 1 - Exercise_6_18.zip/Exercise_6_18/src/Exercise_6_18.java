/**
 * Author: Chandelor Losee
 * Date: Jan 30, 2023
 * 
 * Checks if a password is valid or invalid.
 */
import java.util.Scanner;
public class Exercise_6_18 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a Password: ");
		String s = input.nextLine();
		if (isValid(s)) {
			System.out.println("Valid Password");
		}
		
		else {
			System.out.println("Invalid Password");
		}
		
	}

	public static boolean isValid(String s) {
		
		int d = 0;
		boolean n = false;
		if (s.length() > 7) {
			for (int k = 0; k < s.length(); k++) {
				if ((Character.isDigit(s.charAt(k)) || (Character.isLetter(s.charAt(k))))) {
					n = true;
				}	
			
			}
			
			for (int j = 0; j < s.length() && n != false; j++) {
				if (Character.isDigit(s.charAt(j))) {
					d++;
				}
				
			}
			
			if (n != false && d >= 2) {
				n = true;
			}
			
		}
		
		return n;
	}
	
}
