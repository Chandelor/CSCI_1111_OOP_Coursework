/**
 * Author: 
 * Date: May , 2023
 * 
 * 
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
public class FinalProject {
	public static HashMap<String, String> colors;
	public static String ansiiReset = "\u001B[0m";
	
	public static void main(String[] args) {	
		
		colors = new HashMap<String, String>();
		colors.put("black", "\u001B[30m");
		colors.put("red", "\u001B[31m");
		colors.put("green", "\u001B[32m");
		colors.put("yellow", "\u001B[33m");
		colors.put("blue", "\u001B[34m");
		colors.put("purple", "\u001B[35m");
		colors.put("cyan", "\u001B[36m");
		
		Game.runGame();
	}
	
}

class Game extends BoardSpace {
	
	Game(){
		
	}
	
	public static void runGame() {
		String gameMode = getMode();
		int boardWidth = getBoardWidth(gameMode);
		int boardHeight = getBoardHeight(gameMode);
		BoardSpace[][] gameBoard = createBoard(boardWidth, boardHeight);
		Player[] playerNumber = playerOrder();
		printBoard(boardWidth, boardHeight, gameBoard);
		playerPieceDrop(playerNumber, gameBoard, boardWidth, boardHeight);
	}
		
	public static String getMode() {
		Scanner input = new Scanner(System.in);
		String gameMode = "Null";
		for(boolean keepLoop = true; keepLoop;) {
			System.out.println("Which mode you would like to play?");
			System.out.println("Modes: Default, Custom");
			System.out.print("GameMode: ");
			gameMode = input.nextLine();
			
			if (gameMode.equalsIgnoreCase("Default")) {
				keepLoop = false;
			}
			
			else if (gameMode.equalsIgnoreCase("Custom")) {
				keepLoop = false;
			}
			
			else {
				System.out.println("\nInvalid gamemode, please try again.\n");
			}
			
		}
		
		return gameMode;
	}
	
	public static int getPlayerCount() {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter how many players there will be! (max: 7)");
		System.out.print("Player Count: ");
		int playerCount = input.nextInt();
		return playerCount;
	}
	
	public static Player[] playerOrder() {
		Scanner input = new Scanner(System.in);
		int playerCount = getPlayerCount(); 
		
		ArrayList<String> availableColors = new ArrayList<>();
		
        for (Entry<String, String> entry : FinalProject.colors.entrySet()) {
        	availableColors.add(entry.getKey());
        }
		
		Player[] playerNumber = new Player[playerCount];
		
		System.out.println("\nEach player will now choose a color!");
		for (int n = 0; n < playerCount;) {
			playerNumber[n] = new Player(n);
			printAvailableColors(availableColors);
			System.out.print("Player " + (n + 1) + "'s color: ");
			String userSelectedColor = input.nextLine().toLowerCase();
			
			if (FinalProject.colors.containsKey(userSelectedColor)) {
				availableColors.remove(userSelectedColor);
				for (int n1 = 0; n1 < availableColors.size(); n1++) {
					if (userSelectedColor.equalsIgnoreCase(availableColors.get(n1)) ) {
						availableColors.remove(n1);
					}
				}
				
				playerNumber[n].piece = FinalProject.colors.get(userSelectedColor) + "O" + FinalProject.ansiiReset;
				n++;
			}
			
			else {
				System.out.println("Invalid color please try again.\n");
			}
			
		}
		
		return playerNumber;
	}
	
	public static void printAvailableColors(ArrayList<String> availableColors) {

		System.out.print("Available colors to play as: ");
		for (int n = 0; n < availableColors.size();n++) {
			if (n + 1 == availableColors.size()) {
				System.out.println("or " + FinalProject.colors.get(availableColors.get(n)) + availableColors.get(n) + FinalProject.ansiiReset);
			}
			
			else {
				System.out.print(FinalProject.colors.get(availableColors.get(n)) + availableColors.get(n) + FinalProject.ansiiReset + ", ");
			}
			
		}
		
	}
	
	public static void playerPieceDrop(Player[] playerNumber, BoardSpace[][] gameBoard, int boardWidth, int boardHeight) {
		Scanner input = new Scanner(System.in);
		int userSelectedWinCondition = 4;
		int winCondtion = 0;
		for (int n = 0; winCondtion != userSelectedWinCondition; n++) {
			if (n ==  playerNumber.length) {
				n = 0;
			}
			
			System.out.println("Player " + (playerNumber[n].playerNumber + 1) + " enter a column to drop your piece down!");
			System.out.print("Column to drop: ");
			int playerDrop = input.nextInt() - 1;
			
			if (gameBoard[playerDrop][0].boardSpace == " ") {
				for (int i = 0; i < boardHeight; i++) {
					if (i + 1 < boardHeight) {
						if (gameBoard[playerDrop][i + 1].boardSpace != " ") {
							gameBoard[playerDrop][i].boardSpace = playerNumber[n].piece;
							break;
						}
						
					}
					
					else if (gameBoard[playerDrop][i].boardSpace == " "){
						gameBoard[playerDrop][i].boardSpace = playerNumber[n].piece;
					}
					
				}
				
			}
			
			else {
				System.out.println("\n" + FinalProject.colors.get("red") + "This column is full, please try a different one." + FinalProject.ansiiReset);
			}
		
			printBoard(boardWidth, boardHeight, gameBoard);
		}
		
	}

}

class BoardSpace {
	
	public Player filledBy;
	public String boardSpace = " ";
	
	BoardSpace() {	
	}
	
	public static int getBoardWidth(String gameMode) {
		Scanner input = new Scanner(System.in);
		int boardWidth = 0;
		if (gameMode.equalsIgnoreCase("Custom")) {
			for (;boardWidth < 4 || boardWidth > 20;) {
			System.out.print("Enter the boards Width (min: 4, max: 20): ");
			boardWidth = input.nextInt();
				
				if (boardWidth < 4 || boardWidth > 20) {
					 System.out.println("Invalid width, please try another value.");
				}
				
			}
			
		}
		
		else if (gameMode.equalsIgnoreCase("Default")) {
			boardWidth = 7;
		}
		
		return boardWidth;
			
	}
	
	public static int getBoardHeight(String gameMode) {
		Scanner input = new Scanner(System.in);
		int boardHeight = 0;
		if (gameMode.equalsIgnoreCase("Custom")) {
			for (; boardHeight < 4 || boardHeight > 20;) {
				System.out.print("Enter the boards Height (min: 4, max: 20): ");
				boardHeight = input.nextInt();
			
				if (boardHeight < 4 || boardHeight > 20) {
					System.out.println("Invalid height, please try another value.");
				}
					
			}
				
		}
		
		else if (gameMode.equalsIgnoreCase("Default")) {
			boardHeight = 6;
		}
		
		return boardHeight;
			
	}
	
	public static BoardSpace[][] createBoard(int boardWidth, int boardHeight) {
		BoardSpace[][] gameBoard = new BoardSpace[boardWidth][boardHeight];
		for (int n1 = 0; n1 < boardWidth; n1++) {
			for (int n2 = 0; n2 < boardHeight; n2++) {
				gameBoard[n1][n2] = new BoardSpace();
			}
			
		}
		
		return gameBoard;
	}
	
	public static void printBoard(int boardWidth, int boardHeight, BoardSpace[][] gameBoard) {
		System.out.println();
		for (int n = 0; n < boardWidth; n++) {
			if (n + 1 < 10) {
				System.out.print(" 00" + (n + 1) + "  ");
			}
			
			else if (n + 1 >= 10) {
				System.out.print(" 0" + (n + 1) + "  ");
			}
			
			else {
				System.out.print(" " + (n + 1) + "  ");
			}

		}
		
		System.out.println();
		for (int n = 0; n < boardWidth * 6; n++) {
			System.out.print("-");
		}
		
		for (int n1 = 0; n1 < boardHeight; n1++) {
			System.out.println();
			for (int n2 = 0; n2 < boardWidth; n2++) {
				System.out.print(" (");
				System.out.print(gameBoard[n2][n1].boardSpace);
				System.out.print(")  ");
			}	
			
		}
		
		System.out.println();
		for (int n = 0; n < boardWidth * 6; n++) {
			System.out.print("-");
		}
		
		System.out.println();
	}
	
}

class Player {

	int playerNumber;
	String playerColor;
	String piece;
	
	Player(){
		
	}
	
	Player(int newPlayerNumber){
		playerNumber = newPlayerNumber;
	}
	
}

