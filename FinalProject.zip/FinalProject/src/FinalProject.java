/**
 * @author Chandelor Losee 
 * Date: May , 2023
 * 
 * 
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
public class FinalProject {
	
	public static HashMap<String, String> colors;
	public static String ansiiReset = "\u001B[0m";
	
	public static void main(String[] args) {	
		
		colors = new HashMap<String, String>();
//		colors.put("black", "\u001B[30m");
		colors.put("red", "\u001B[31m");
		colors.put("green", "\u001B[32m");
		colors.put("yellow", "\u001B[33m");
		colors.put("blue", "\u001B[34m");
		colors.put("purple", "\u001B[35m");
		colors.put("white",	"\u001B[37m");
		
		Game.runGame();
	}
	
}
/*
* The Game class will pull all of the methods from the BoardSpace class and utilize them to run the game.
* It also gathers information from the user about the board size, how many in a row to win the game, player count, player order, player color, where to drop a piece on the board,
* and checks if the win condtion has been met.
*/
class Game extends BoardSpace {
	
	Game(){
		
	}
/*	
* This method gives information to all of the methods needed to run the game and will loop the game if the user has selected to.
*/
	public static void runGame() {
		Scanner input = new Scanner(System.in);
		String gameMode = getMode();
		int boardWidth = getBoardWidth(gameMode);
		int boardHeight = getBoardHeight(gameMode);
		int userSelectedWinCondition = getWinCondition(boardWidth, boardHeight);
		Player[] playerNumber = playerOrder();
			
		for (String continueGame = "yes"; continueGame.equalsIgnoreCase("yes");) {
			BoardSpace[][] gameBoard = createBoard(boardWidth, boardHeight);
			printBoard(boardWidth, boardHeight, gameBoard);
			playerPieceDrop(playerNumber, gameBoard, boardWidth, boardHeight, userSelectedWinCondition);
			continueGame = "no";
			System.out.print("\nKeep Playing? (Yes/No): ");
			continueGame = input.nextLine();
			
			if (continueGame.equalsIgnoreCase("no")) {
				System.out.println("\nThanks for Playing!");
			}
			
		}
		
	}
/*	
* Gets an input from the user to decide if the board will be the default 7x6 size or a custom board size.
*/
	public static String getMode() {
		Scanner input = new Scanner(System.in);
		String gameMode = "Null";
		for(int n = 0; n == 0;) {
			System.out.print("Play with default board size? (yes/no): ");
			gameMode = input.nextLine();
			
			if (gameMode.equalsIgnoreCase("yes")) {
				n++;
			}
			
			else if (gameMode.equalsIgnoreCase("no")) {
				n++;
			}
			
			else {
				System.out.println(FinalProject.colors.get("red") + "\nInvalid, please try again.\n" + FinalProject.ansiiReset);
			}
			
		}
		
		return gameMode;
	}
/*
* Gets an input from the user on how many pieces of the same color need to line up for the game to be won.
*/
	public static int getWinCondition(int boardWidth, int boardHeight) {
		Scanner input = new Scanner(System.in);
		int userSelectedWinCondition = 0;
		while (userSelectedWinCondition > boardWidth || userSelectedWinCondition > boardHeight || userSelectedWinCondition <= 1) {
			System.out.print("How many in a row to win: ");
			userSelectedWinCondition = input.nextInt();

			if (userSelectedWinCondition > boardWidth || userSelectedWinCondition > boardHeight) {
				System.out.println(FinalProject.colors.get("red") + "\nInvalid, please enter a number that does not exceed the board size." + FinalProject.ansiiReset);
				System.out.println("Width: " + boardWidth + "\nHeight: " + boardHeight);
			}
			
			else if (userSelectedWinCondition <= 1) {
				System.out.println(FinalProject.colors.get("red") + "\nInvalid, please enter a number greater than 1." + FinalProject.ansiiReset);
			}
			
		}
			
		return userSelectedWinCondition;
	}
/*
* Gets an input from the user on how many players there will be.
*/
	public static int getPlayerCount() {
		Scanner input = new Scanner(System.in);
		int playerCount = 0;
		while (playerCount > FinalProject.colors.size() || playerCount <= 0) {
			System.out.print("How many players (max: " + FinalProject.colors.size() + "): ");
			playerCount = input.nextInt();
			
			if (playerCount > FinalProject.colors.size() || playerCount <= 0) {
				System.out.println(FinalProject.colors.get("red") + "\nInvalid, please enter a player count between 0 and " + FinalProject.colors.size() + "." + FinalProject.ansiiReset);
			}
			
		}
		
		return playerCount;
	}
/*
* Creates an array of Player objects based on how many players were entered, and then has each player pick a color that is assigned to their order.
*/
	public static Player[] playerOrder() {
		Scanner input = new Scanner(System.in);
		int playerCount = getPlayerCount(); 
		
		ArrayList<String> availableColors = new ArrayList<>();
		
        for (Entry<String, String> entry : FinalProject.colors.entrySet()) {
        	availableColors.add(entry.getKey());
        }
		
		Player[] playerNumber = new Player[playerCount];

		printAvailableColors(availableColors);
		for (int n = 0; n < playerCount;) {
			playerNumber[n] = new Player(n);
			System.out.print("Player " + (n + 1) + "'s color: ");
			String userSelectedColor = input.nextLine().toLowerCase();
			
			if (availableColors.contains(userSelectedColor)) {
				availableColors.remove(userSelectedColor);
				for (int n1 = 0; n1 < availableColors.size(); n1++) {
					if (userSelectedColor.equalsIgnoreCase(availableColors.get(n1)) ) {
						availableColors.remove(n1);
					}
				}
				
				playerNumber[n].piece = FinalProject.colors.get(userSelectedColor) + "O" + FinalProject.ansiiReset;
				n++;
			}
			
			else {
				System.out.println(FinalProject.colors.get("red") + "\nInvalid, please try a different color!\n" + FinalProject.ansiiReset);
				printAvailableColors(availableColors);
			}
			
		}
		
		return playerNumber;
	}
/*	
* This method will print all of the colors that haven't been selected by a player.
*/
	public static void printAvailableColors(ArrayList<String> availableColors) {

		System.out.print("Available colors to play as: ");
		for (int n = 0; n < availableColors.size();n++) {
			if (n + 1 == availableColors.size()) {
				System.out.println("or " + FinalProject.colors.get(availableColors.get(n)) + availableColors.get(n) + FinalProject.ansiiReset);
			}
			
			else {
				System.out.print(FinalProject.colors.get(availableColors.get(n)) + availableColors.get(n) + FinalProject.ansiiReset + ", ");
			}
			
		}
		
	}
/*
* Will ask each player which column they want to drop there piece into.
* It will then check each object array in that column to see if the one below it is availabe to drop a piece into and if not will drop the piece into the spot above it.
*/
	public static void playerPieceDrop(Player[] playerNumber, BoardSpace[][] gameBoard, int boardWidth, int boardHeight, int userSelectedWinCondition) {
		Scanner input = new Scanner(System.in);
		int winCondition = 0;
		for (int n = 0; winCondition != userSelectedWinCondition;) {
			int playerColumnDrop = -1;
			if (n ==  playerNumber.length) {
				n = 0;
			}
			
			winCondition = checkForWin(playerNumber, gameBoard, winCondition, userSelectedWinCondition, boardWidth, boardHeight);
			if (winCondition == userSelectedWinCondition) {
				break;
			}
			
			while (playerColumnDrop > boardWidth - 1|| playerColumnDrop < 0) {
				System.out.print("Player " + (playerNumber[n].playerNumber + 1) + " enter a column to drop your piece down: ");
				playerColumnDrop = input.nextInt() - 1;
				
				if (playerColumnDrop > boardWidth - 1) {
					System.out.println(FinalProject.colors.get("red") + "\nInvalid, please enter a column inside of the boards width." + FinalProject.ansiiReset);
					printBoard(boardWidth, boardHeight, gameBoard);
				}
				
			}
			
			if (gameBoard[0][playerColumnDrop].boardSpace == " ") {
				for (int i = 0; i < boardHeight; i++) {
					if (i + 1 < boardHeight) {
						if (gameBoard[i + 1][playerColumnDrop].boardSpace != " ") {
							gameBoard[i][playerColumnDrop].boardSpace = playerNumber[n].piece;
							gameBoard[i][playerColumnDrop].filledBy = playerNumber[n];
							n++;
							break;
						}
						
					}
					
					else if (gameBoard[i][playerColumnDrop].boardSpace == " "){
						gameBoard[i][playerColumnDrop].boardSpace = playerNumber[n].piece;
						gameBoard[i][playerColumnDrop].filledBy = playerNumber[n];
						n++;
					}
					
				}
				
			}
			
			else {
				System.out.println("\n" + FinalProject.colors.get("red") + "This column is full, please try a different one." + FinalProject.ansiiReset);
			}
		
			printBoard(boardWidth, boardHeight, gameBoard);
		}
		
	}
/*
* After each piece has been dropped a scanner will run to check if a player has reached the win condition of that many pieces in a row.
* If the win condition has been met the player who won will be printed.
*/
	public static int checkForWin(Player[] playerNumber, BoardSpace[][] gameBoard, int winCondition, int userSelectedWinCondition, int boardWidth, int boardHeight) {
		
		for (int height = 0; height < boardHeight && winCondition != userSelectedWinCondition; height++) {
			for (int width = 0; width < boardWidth && winCondition != userSelectedWinCondition; width++) {
				if (gameBoard[height][width].boardSpace != " ") {
					winCondition = 0;
					winCondition++;
					for (int h1 = 0; h1 < userSelectedWinCondition && winCondition != userSelectedWinCondition; h1++) {
						if (h1 + height + 1 < boardHeight) {
							if (gameBoard[h1 + height][width].boardSpace == gameBoard[h1 + height + 1][width].boardSpace) {
								winCondition++;
							}
							
							else {
								winCondition = 0;
								break;
							}
							
						}
						
					}

					if (winCondition != userSelectedWinCondition) {
						winCondition = 0;
						winCondition++;	
					}
					
					for (int w1 = 0; w1 < userSelectedWinCondition && winCondition != userSelectedWinCondition; w1++) {
						if (w1 + width + 1 < boardWidth) {
							if (gameBoard[height][w1 + width].boardSpace == gameBoard[height][w1 + width + 1].boardSpace) {
								winCondition++;
							}
							
							else {
								winCondition = 0;
								break;
							}
							
						}
						
					}
						
					if (winCondition != userSelectedWinCondition) {
						winCondition = 0;
						winCondition++;	
					}
						
					for (int w1 = 0, h1 = 0; w1 < userSelectedWinCondition && winCondition != userSelectedWinCondition; w1++ , h1++) {
						if (w1 + width + 1 < boardWidth && h1 + height + 1 < boardHeight) {
							if (gameBoard[h1 + height][w1 + width].boardSpace == gameBoard[h1 + height + 1][w1 + width + 1].boardSpace) {
								winCondition++;
							}
							
							else {
								winCondition = 0;
								break;
							}
							
						}
						
					}
					
					if (winCondition != userSelectedWinCondition) {
						winCondition = 0;
						winCondition++;	
					}
					
					for (int w1 = 0, h1 = 0; h1 < userSelectedWinCondition && winCondition != userSelectedWinCondition; w1-- , h1++) {
						if (w1 + width - 1 >= 0 && h1 + height + 1 < boardHeight) {
							if (gameBoard[h1 + height][w1 + width].boardSpace == gameBoard[h1 + height + 1][w1 + width - 1].boardSpace) {
								winCondition++;
							}
							
							else {
								winCondition = 0;
								break;
							}
							
						}
						
					}
					
				}
				
				if (winCondition == userSelectedWinCondition) {
					for (int n = 0; n < playerNumber.length; n++) {
						if (playerNumber[n].piece == gameBoard[height][width].boardSpace) {
							System.out.println("Player " + (playerNumber[n].playerNumber + 1) + " has won!");
						}
						
					}
					
				}
				
			}
			
		}
		
		return winCondition;
	}

}
/*
* This class will get the board width and height from the user if they selected a custom board size, if left to default will, create a pre defined board size and then print it.
*/
class BoardSpace {
	
	public Player filledBy;
	public String boardSpace = " ";
	
	BoardSpace() {	
	}
/*
* Gets input from gamemode to see if the user had selected to us a custom board or not.
* If yes will send a pre defined board size, else will ask the user for input on how wide the board should be, with a limit of 21 spaces, and a min of 2 spaces.
*/
	public static int getBoardWidth(String gameMode) {
		Scanner input = new Scanner(System.in);
		int boardWidth = 0;
		if (gameMode.equalsIgnoreCase("no")) {
			while (boardWidth < 2 || boardWidth > 21 || boardWidth < 0) {
				System.out.print("Enter the boards Width (min: 2, max: 21): ");
				boardWidth = input.nextInt();
				
				if (boardWidth < 2 || boardWidth > 21 || boardWidth < 0) {
					 System.out.println(FinalProject.colors.get("red") + "Invalid width, please try another value." + FinalProject.ansiiReset);
				}
				
			}
			
		}
		
		else if (gameMode.equalsIgnoreCase("yes")) {
			boardWidth = 7;
		}
		
		return boardWidth;
			
	}
/*
* Gets input from gamemode to see if the user had selected to us a custom board or not.
* If yes will send a pre defined board size, else will ask the user for input on how high the board should be, with a limit of 21 spaces, and a min of 2 spaces.	
*/
	public static int getBoardHeight(String gameMode) {
		Scanner input = new Scanner(System.in);
		int boardHeight = 0;
		if (gameMode.equalsIgnoreCase("no")) {
			while (boardHeight < 2 || boardHeight > 21 || boardHeight < 0) {
				System.out.print("Enter the boards Height (min: 2, max: 21): ");
				boardHeight = input.nextInt();
			
				if (boardHeight < 2 || boardHeight > 21 || boardHeight < 0) {
					System.out.println(FinalProject.colors.get("red") + "Invalid height, please try another value." + FinalProject.ansiiReset);
				}
					
			}
				
		}
		
		else if (gameMode.equalsIgnoreCase("yes")) {
			boardHeight = 6;
		}
		
		return boardHeight;
			
	}
/*
* This method will create a multi dimensional object array for each space that can be on the game board.
* It will then make sure that each space has been activated.
*/
	public static BoardSpace[][] createBoard(int boardWidth, int boardHeight) {
		BoardSpace[][] gameBoard = new BoardSpace[boardHeight][boardWidth];
		for (int n1 = 0; n1 < boardWidth; n1++) {
			for (int n2 = 0; n2 < boardHeight; n2++) {
				gameBoard[n2][n1] = new BoardSpace();
			}
			
		}
		
		return gameBoard;
	}
/*	
* Prints out the column headers as well as a divider line, brackets to show the available game spaces (and any pieces that might be in those spaces), and a closing divider line.
*/
	public static void printBoard(int boardWidth, int boardHeight, BoardSpace[][] gameBoard) {
		System.out.println();
		for (int n = 0; n < boardWidth; n++) {
			if (n + 1 < 10) {
				System.out.print(" 00" + (n + 1) + "  ");
			}
			
			else if (n + 1 >= 10) {
				System.out.print(" 0" + (n + 1) + "  ");
			}
			
			else {
				System.out.print(" " + (n + 1) + "  ");
			}

		}
		
		System.out.println();
		for (int n = 0; n < boardWidth * 6; n++) {
			System.out.print("-");
		}
		
		for (int n1 = 0; n1 < boardHeight; n1++) {
			System.out.println();
			for (int n2 = 0; n2 < boardWidth; n2++) {
				System.out.print(" (");
				System.out.print(gameBoard[n1][n2].boardSpace);
				System.out.print(")  ");
			}	
			
		}
		
		System.out.println();
		for (int n = 0; n < boardWidth * 6; n++) {
			System.out.print("-");
		}
		
		System.out.println();
	}
	
}
/*
* This class will store a players number and which color their piece is.
*/
class Player {

	int playerNumber;
	String piece;
	
	Player(){
		
	}
	
	Player(int newPlayerNumber){
		playerNumber = newPlayerNumber;
	}
	
}
