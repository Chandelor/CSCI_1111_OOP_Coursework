/**
 * Author: Chandelor Losee
 * Date: Mar 10, 2023
 * 
 * 
 */
import java.util.Random;
public class Exercise_13_7 {

	public static void main(String[] args) {
		
		Triangle[] t1 = new Triangle[5];
		
		for (int n = 0; n < 5; n++) {
			Random randomNum = new Random();
			t1[n] = new Triangle();
			t1[n].side1 = randomNum.nextInt(10) + 1;
			t1[n].side2 = randomNum.nextInt(10) + 1;
			t1[n].side3 = randomNum.nextInt(10) + 1;
			
			if ((int)(Math.random() * 2) == 1) {
				t1[n].filled = true;
			}
			
			else {
				t1[n].filled = false;
			}
			
		}
		
		for (int n = 0; n < t1.length;n++) {
			double area = t1[n].getArea(t1[n].side1, t1[n].side2, t1[n].side3);
			if (area == area) {
				System.out.println("\nTriangle: " + (n + 1));
				System.out.println("Side 1: " + t1[n].side1);
				System.out.println("Side 2: " + t1[n].side2);
				System.out.println("Side 3: " + t1[n].side3);
				System.out.printf("Area of the triangle: %.2f\n",  t1[n].getArea(t1[n].side1, t1[n].side2, t1[n].side3));
				System.out.println("The triangle is filled: " + t1[n].filled);
				t1[n].howToColor();
			}	
			
			else {
				System.out.println("\nTriangle: " + (n + 1));
				System.out.println("Side 1: " + t1[n].side1);
				System.out.println("Side 2: " + t1[n].side2);
				System.out.println("Side 3: " + t1[n].side3);
				System.out.println("Area of the triangle: Not a triangle");
				System.out.println("The triangle is filled: " + t1[n].filled);
				t1[n].howToColor();
			}
			
		}

	}

}

abstract class GeometricObject {
	
	GeometricObject() {
		
	}
	
	public double getArea(double s1, double s2, double s3) {
		double s = getPerimeter(s1, s2, s3);
		return Math.sqrt(s * (s - s1) * (s - s2) * (s - s3));
	}
	
	public double getPerimeter(double s1, double s2, double s3) {
		return (s1 + s2 + s3) / 2;
	}
	
	public String toString(double s1, double s2, double s3) {
		return "Triangle: side1 = " + s1 + " side2 = " + s2 + " side3 = " + s3;
	}
	
}

interface colorable {
	
	void howToColor();
	
}

class Triangle extends GeometricObject implements colorable{
	
	public double side1 = 1;
	public double side2 = 1;
	public double side3 = 1;
	public String color = "";
	public boolean filled;
	
	Triangle() {
		
	}
	
	Triangle(double s1, double s2, double s3, String newColor, boolean isFilled) {
		side1 = s1;
		side2 = s2;
		side3 = s3;
		filled = isFilled;
	}
	
	public boolean getFilled() {
		return filled;
	}
	
	public double getSide1() {
		return side1;
	}
	
	public double getSide2() {
		return side2;
	}
	
	public double getSide3() {
		return side3;
	}
	
	public void howToColor() {
		System.out.println("Color all three sides.");
	}
		
}