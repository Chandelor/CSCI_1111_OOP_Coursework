/**
 * Author: Chandelor Losee
 * Date: Mar 21, 2023
 * 
 * 
 */
public class Exercise_13_11 {

	public static void main(String[] args) {
		
		Octagon o1 = new Octagon(10);
		Octagon o2 = (Octagon) o1.clone();

		System.out.println(o1.compareTo(o2));
		
		System.out.print("Object 1 Area: ");
		System.out.printf("%.2f", o1.getArea());
		
		System.out.print("\nObject 2 Area: ");
		System.out.printf("%.2f", o2.getArea());
	}

}

class GeometricObject {
	
	GeometricObject() {
	}
	
}

class Octagon extends GeometricObject implements Comparable<Octagon>, Cloneable {
	
	public double sideLength;
	
	Octagon() {
	}
	
	Octagon(double newSideLength) {
		sideLength = newSideLength;
	}
	
	public double getArea() {
		return (2 + (4 / Math.sqrt(2))) * sideLength * sideLength;
	}

	public Object clone() {
		
		try {
			return super.clone();
		}
		
		catch (CloneNotSupportedException ex) {
			return null;
		}
		
	}
	
	@Override
	public int compareTo(Octagon o) {
		if (getArea() > o.getArea()) {
			return 1;
		}
		
		else if (getArea() < o.getArea()) {
			return -1;
		}
		
		else {
			return 0;
		}
		
	}
	
}