/**
 * Author: Chandelor Losee
 * Date: Feb 23, 2023
 * 
 * Takes an input for 3 sides of a triangle and finds the area/perimeter and if the triangle is filled, has a color, and the date it was created.
 */
import java.util.Scanner;
import java.util.Date;
public class Exercise_11_1 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a color for a triangle, a number for each of the sides, and whether the triangle is filled or not.");
		System.out.print("Color: ");
		String color = input.nextLine();
		System.out.print("Side1: ");
		double side1 = input.nextDouble();
		System.out.print("Side2: ");
		double side2 = input.nextDouble();
		System.out.print("Side3: ");
		double side3 = input.nextDouble();
		System.out.print("Is the triangle filled (true/false): ");
		boolean filled = input.nextBoolean();

		Triangle t1 = new Triangle(side1, side2, side3, color, filled);
		
		System.out.printf("\nArea of the triangle: %.2f\n",  t1.getArea(side1, side2, side3));
		System.out.printf("Perimeter of the triangle: %.2f\n",  t1.getPerimeter(side1, side2, side3));
		System.out.println("Color of the triangle: " + t1.color);
		System.out.println("Date the triangle was create: " + t1.date);
		System.out.println("The triangle is filled: " + t1.filled);
		
	}
	
}

class GeometricObject {
	
	GeometricObject() {
		
	}
	
	public double getArea(double s1, double s2, double s3) {
		double s = getPerimeter(s1, s2, s3);
		return Math.sqrt(s * (s - s1) * (s - s2) * (s - s3));
	}
	
	public double getPerimeter(double s1, double s2, double s3) {
		return (s1 + s2 + s3) / 2;
	}
	
	public String toString(double s1, double s2, double s3) {
		return "Triangle: side1 = " + s1 + " side2 = " + s2 + " side3 = " + s3;
	}
	
}

class Triangle extends GeometricObject {
	
	private double side1 = 1;
	private double side2 = 1;
	private double side3 = 1;
	public String color = "";
	public boolean filled;
	public Date date = new Date(); 
	
	Triangle() {
		
	}
	
	Triangle(double s1, double s2, double s3, String newColor, boolean isFilled) {
		side1 = s1;
		side2 = s2;
		side3 = s3;
		color = newColor;
		filled = isFilled;
		
	}
	
	public double getSide1() {
		return side1;
	}
	
	public double getSide2() {
		return side2;
	}
	
	public double getSide3() {
		return side3;
	}
		
}
	

