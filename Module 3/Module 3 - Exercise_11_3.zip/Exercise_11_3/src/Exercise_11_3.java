
/**
 * Author: Chandelor Losee
 * Date: Feb 24, 2023
 * 
 * Creates 1 basic account, 1 checking account, and 1 saving account, with the checking account having a overdraft limit of $100,
 * and the savings account not allowing a withdrawal that will put the balance below $0.
 */

import java.util.Date;
public class Exercise_11_3 {

	public static void main(String[] args) {
		
		Account a1 = new Account();
		a1.setId(1);
		a1.setBalance(500);
		System.out.println(a1.toString());
		
		Checkings c1 = new Checkings();
		c1.setId(1);
		c1.setBalance(500);
		System.out.println("\n" + c1.toString());
		c1.withdraw(600);
		c1.withdraw(1);
		
		Savings s1 = new Savings();
		s1.setId(1);
		s1.setBalance(500);
		System.out.println("\n" + s1.toString());
		s1.withdraw(500);
		s1.withdraw(501);
	}

}

class Account{
	
	private int id = 0;
	private double balance = 0;
	private static double annualInterestRate = 0;
	private Date date = new Date();
	
	Account(){	
		id = 0;
		balance = 0;
	}
	
	Account(int newId, double newBalance){
		id = newId;
		balance = newBalance;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int newId) {
		id = newId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double newBalance) {
		balance = newBalance;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public void setAnnualInterestRate(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	public Date getDate() {
		return date;
	}
	
	public double getMonthlyInterestRate(double newAnnualInterestRate) {
		return newAnnualInterestRate / 100;
	}
	
	public double getMonthlyInterest(double newBalance) {
		return newBalance * getMonthlyInterestRate(annualInterestRate);
	}
	
	public void withdraw(double amount) {
		balance -= amount;
	}
	
	public void deposit(double amount) {
		balance += amount;
	}
	
	public String toString() {
		return "The account's id is " + id + ", with a balance of $" + balance + ", and was created on " + date;
	}
	
}

class Checkings extends Account {
	
	Checkings() {
		
	}
	
	public void withdraw(double amount) {
		if (getBalance() - amount > -101) {
			System.out.println("Withdrawing $" + amount + " from checkings account id " + getId() + ".");
			setBalance(getBalance() - amount);
			System.out.println("New Balance: $" + getBalance() + ".");
		}
		
		else {
			System.out.println("Cannot withdraw $" + amount + ", as the amount would exceed the overdraft limit of $100.");
		}
		
	}
	
	public String toString() {
		return "The checking account id is " + getId() + ", with a balance of $" + getBalance() 
		+ ", an overdraft limit of $100, and was created on " + getDate();
	}
	
}

class Savings extends Account {
	
	Savings() {
		
	}
	
	public void withdraw(double amount) {
		if (getBalance() - amount > -1) {
			System.out.println("Withdrawing $" + amount + " from savings account id " + getId() + ".");
			setBalance(getBalance() - amount);
			System.out.println("New Balance: $" + getBalance() + ".");
		}
		
		else {
			System.out.println("Cannot withdraw $" + amount + ", as the amount would exceed the current balance of $" + getBalance() + ".");
		}
		
	}
	
	public String toString() {
		return "The saving account id is " + getId() + ", with a balance of $" + getBalance() 
		+ ", cannot be overdrawn, and was created on " + getDate();
	}
	
}

