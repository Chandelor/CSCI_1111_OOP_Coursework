/**
 * Author: Chandelor Losee
 * Date: Feb 3, 2023
 * 
 * This code will print the area and parimeter of a rectangle.
 */
public class Exercise_9_1 {

	public static void main(String[] args) {
		
		Rectangle rectangle1 = new Rectangle(4, 40);
		System.out.println("A rectangle with a width of " + rectangle1.width + " and a height of " + rectangle1.height + 
				" has an area of " + rectangle1.getArea() + " and a parimeter of " + rectangle1.getPerimeter());

		Rectangle rectangle2 = new Rectangle(3.5, 35.9);
		System.out.println("A rectangle with a width of " + rectangle2.width + " and a height of " + rectangle2.height + 
				" has an area of " + rectangle2.getArea() + " and a parimeter of " + rectangle2.getPerimeter());
	}
	
}

	class Rectangle {
		
		double width;
		double height;
		
		Rectangle() {
			double width = 1;
			double height = 1;
		}
		
		Rectangle(double newWidth, double newHeight){
			width = newWidth;
			height = newHeight;
		}
		
		double getArea() {
			return width * height;
		}
		
		double getPerimeter() {
			return (width * 2) * (height * 2);
		}
		
	}
	
