/**
 * Author: Chandelor Losee
 * Date: Feb 6, 2023
 * 
 * 
 */
import java.util.Date;
public class Exercise_9_7 {

	public static void main(String[] args) {
		
		Account account1 = new Account();
		account1.setId(1122);
		account1.setBalance(20000);
		account1.setAnnualInterestRate(0.045);
		account1.withdraw(2500);
		account1.deposit(3000);
		System.out.println("Id: " + account1.getId());
		System.out.println("Balance: $" + account1.getBalance());
		System.out.println("Interest Rate: " + account1.getAnnualInterestRate() * 100 + "%");
		System.out.printf("Interest: $%4.2f\n", account1.getMonthlyInterest(account1.getBalance()));
		System.out.println("Date: " + account1.getDate());
	}

}

class Account{
	
	private int id = 0;
	private double balance = 0;
	private static double annualInterestRate = 0;
	private Date dateCreated = new Date();
	
	Account(){	
		id = 0;
		balance = 0;
	}
	
	Account(int newId, double newBalance){
		id = newId;
		balance = newBalance;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int newId) {
		id = newId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double newBalance) {
		balance = newBalance;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public void setAnnualInterestRate(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	public Date getDate() {
		return dateCreated;
	}
	
	public double getMonthlyInterestRate(double newAnnualInterestRate) {
		return newAnnualInterestRate / 100;
	}
	
	public double getMonthlyInterest(double newBalance) {
		return newBalance * getMonthlyInterestRate(annualInterestRate);
	}
	
	public double withdraw(double amount) {
		return balance -= amount;
	}
	
	public double deposit(double amount) {
		return balance += amount;
	}
	
}
