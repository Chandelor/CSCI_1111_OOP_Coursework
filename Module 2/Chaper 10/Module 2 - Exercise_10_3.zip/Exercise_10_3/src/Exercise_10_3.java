/**
 * Author: Chandelor Losee
 * Date: Feb 10, 2023
 * 
 * 
 */
public class Exercise_10_3 {

	public static void main(String[] args) {
		
		int testNumber = 22;
		MyInteger test = new MyInteger(testNumber);
		
		System.out.println("Value is: " + test.getValue());
		System.out.println("Value is Even: " + test.isEven());
		System.out.println("Value is Odd: " + test.isOdd());
		System.out.println("Value is Prime: " + test.isPrime());
		
		System.out.println("\nStatic methods with (int)");
		System.out.println("Value is: " + testNumber);
		System.out.println("Value is Even: " + MyInteger.isEvenInt(testNumber));
		System.out.println("Value is Odd: " + MyInteger.isOddInt(testNumber));
		System.out.println("Value is Prime: " + MyInteger.isPrimeInt(testNumber));
		System.out.println("Value is Even: " + MyInteger.isEvenMyInteger(test));
		
		System.out.println("\nStatic methods with (MyInteger)");
		System.out.println("Value is: " + testNumber);
		System.out.println("Value is Even: " + MyInteger.isEvenMyInteger(test));
		System.out.println("Value is Odd: " + MyInteger.isOddMyInteger(test));
		System.out.println("Value is Prime: " + MyInteger.isPrimeMyInteger(test));
		
		System.out.println("\nObject value and class value are the same(int): " + test.equals(testNumber));
		System.out.println("Object value and class value are the same(MyInteger): " + test.equals(test));
		
		char[] arrayToInt = {'1', '2', '3', '4' ,'5'};
		String stringToInt = "12345"; 
		System.out.println("\nArray to Integer: " + MyInteger.parseInt(arrayToInt));
		System.out.println("String to Integer: " + MyInteger.parseInt(stringToInt));
	}

}

class MyInteger {
	
	public int value = 22;
	
	public MyInteger(int newValue) {
		value = newValue;
	}
	
	public int getValue() {
		return value;
	}
	
	public boolean isEven() {
		if (value % 2 == 0) {
			return true;
		}
		
		return false;
	}
	
	public boolean isOdd() {
		if (value % 2 != 0) {
			return true;
		}
		
		return false;
	}
	
	public boolean isPrime() {	
		if (value <= 1) {
			return false;
		}
		
		for (int n = 2; n <= value; n++) {
			if (value % 2 == 0) {
				return false;
			}
			
		}
		
		return true;
	}
	
	public static boolean isEvenInt(int newValue) {
		MyInteger test = new MyInteger(newValue);
		return test.isEven();
	}
	
	public static boolean isOddInt(int newValue) {
		MyInteger test = new MyInteger(newValue);
		return test.isOdd();
	}
	
	public static boolean isPrimeInt(int newValue) {
		MyInteger test = new MyInteger(newValue);
		return test.isPrime();
	}
	
	public static boolean isEvenMyInteger(MyInteger newValue) {
		return newValue.isEven();
	}
	
	public static boolean isOddMyInteger(MyInteger newValue) {
		return newValue.isOdd();
	}
	
	public static boolean isPrimeMyInteger(MyInteger newValue) {
		return newValue.isPrime();
	}
	
	public boolean equals(int newValue) {
		if (value == newValue) {
			return true;
		}
		
		return false;
	}
	
	public boolean equals(MyInteger newValue) {
		if (value == newValue.getValue()) {
			return true;
		}
		
		return false;
	}
	
	public static int parseInt(char arrayToInt[]) {
		return MyInteger.parseInt(String.valueOf(arrayToInt));
	}
	
	public static int parseInt(String stringToInt) {
		return Integer.parseInt(stringToInt);
	}
	
}