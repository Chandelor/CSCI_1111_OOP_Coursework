/**
 * Author: Chandelor Losee
 * Date: Feb 13, 2023
 * 
 * 
 */
import java.util.Scanner;
import java.util.Date;
public class Exercise_10_7 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Account[] idArray = new Account[10];
		
		for (int n = 0; n < idArray.length; n++) {
			idArray[n] = new Account();
			idArray[n].setId(n);
			idArray[n].setBalance(100);
		}
		
		while (true) {
			System.out.println("Enter an ID: ");
			int userInput = input.nextInt();
			int userSelection = 0;
			
			if (0 <= userInput && userInput <= 9) {
				while (userSelection != 4) {
					System.out.println("\nMain Menu");
					System.out.println("1) Check Balance");
					System.out.println("2) Withdraw");
					System.out.println("3) Deposit");
					System.out.println("4) Exit");
					System.out.println("Enter a selection: ");
					userSelection = input.nextInt();
				
					if (1 <= userSelection && userSelection <=4) {
						switch (userSelection) {
							case 1: System.out.printf("The balance is: $%5.2f\n", idArray[userInput].getBalance()); break;
							case 2: System.out.println("Enter an amount to withdraw: $"); idArray[userInput].withdraw(input.nextInt()); break;
							case 3: System.out.println("Enter an amount to deposit: $"); idArray[userInput].deposit(input.nextInt()); break;
							case 4:	break;
						}
						
					}
					
					else {
						System.out.println("Invalid Selection");
						continue;
					}
					
				}
				
			}
			
			else {
				System.out.println("Invalid ID\n");
				continue;
			}
				
		}
		
	}

}

class Account{
	
	private int id = 0;
	private double balance = 0;
	private static double annualInterestRate = 0;
	private Date dateCreated = new Date();
	
	Account(){	
		id = 0;
		balance = 0;
	}
	
	Account(int newId, double newBalance){
		id = newId;
		balance = newBalance;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int newId) {
		id = newId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double newBalance) {
		balance = newBalance;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public void setAnnualInterestRate(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	public Date getDate() {
		return dateCreated;
	}
	
	public double getMonthlyInterestRate(double newAnnualInterestRate) {
		return newAnnualInterestRate / 100;
	}
	
	public double getMonthlyInterest(double newBalance) {
		return newBalance * getMonthlyInterestRate(annualInterestRate);
	}
	
	public double withdraw(double amount) {
		return balance -= amount;
	}
	
	public double deposit(double amount) {
		return balance += amount;
	}
	
}
