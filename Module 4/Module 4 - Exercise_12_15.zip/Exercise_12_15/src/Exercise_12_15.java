/**
 * Author: Chandelor Losee
 * Date: Feb 28, 2023
 * 
 * Creates a txt file and writes 100 random integers to it, then calls the integers back and sorts them in ascending order.
 */
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
public class Exercise_12_15 {

	public static void main(String[] args) throws java.io.IOException {
		
		int[] sortNum = new int[100];
		
		try {
			File testFile = new File("Exercise_12_15.txt");
		}

		catch(Exception e) {
			System.out.println("File already exists.");
		}
		
		PrintWriter output = new PrintWriter("Exercise_12_15.txt");
		Scanner input = new Scanner(new File("Exercise_12_15.txt"));

		
		for (int n = 0; n < 100; n++) {
			output.print((int)(Math.random() * 999));
			output.print(" ");
			
		}
		
		output.close();
		
		
		for(int m = 0; m < sortNum.length; m++) {
			sortNum[m] = input.nextInt();
		}
		
		Arrays.sort(sortNum);
		for (int n = 0; n < 100; n++) {
			System.out.print(sortNum[n] + " ");
		
			if ((n + 1) % 10 == 0 && n != 0) {
				System.out.println();
			}
			
		}
		
	}

}
