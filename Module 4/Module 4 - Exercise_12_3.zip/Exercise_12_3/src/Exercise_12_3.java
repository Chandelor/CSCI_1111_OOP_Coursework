/**
 * Author: Chandelor Losee
 * Date: Feb 28, 2023
 * 
 * Creates an integer array with 100 random numbers, and gets a user input to check the number at the index location.
 * If user input is greater than the array length, prints "out of bounds".
 */
import java.util.Scanner;
public class Exercise_12_3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] randomInt = new int[100];
		
		for (int n = 0; n < randomInt.length; n++) {
			randomInt[n] = (int)(Math.random() * 999);
		}
		
		for (int n = 0; n == 0;) {
			try {
				System.out.println("Enter a number between 1 and 100.");
				System.out.print("Number: ");
				int userInput = input.nextInt() - 1;
				System.out.println("\n" + randomInt[userInput]);
				n++;
			}
			
			catch(ArrayIndexOutOfBoundsException ex) {
				System.out.println("Out of Bounds.");
			}
		
		}
			
	}

}
