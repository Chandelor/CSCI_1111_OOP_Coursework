import java.util.Scanner;
public class Exercise_6_19 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the length of the 3 sides of the triangle: ");
		double side1 = input.nextInt();
		double side2 = input.nextInt();
		double side3 = input.nextInt();
		
		if (Triangle.isValid(side1, side2, side3) == false) {
			System.out.print("\nThat is not a valid triangle.");
		}
		
		else {
			System.out.printf("\nSide 1: %2.1f\n", side1);
			System.out.printf("Side 2: %2.1f\n", side2);
			System.out.printf("Side 3: %2.1f\n", side3);
			System.out.println("-----------");
			System.out.printf("Area: %5.1f\n", Triangle.area(side1, side2, side3));
		}
		
	}

}

class Triangle {
	/** Return true if the sum of every two sides is greater than the third side.*/
	public static boolean isValid(double side1, double side2, double side3) {
		
		boolean s = false;
		
		if (((side1 + side2 ) > side3 && (side2 + side3) > side1) && (side1 + side3) > side2) {
			s = true;
		}
		
		return s;
	}
	
	/** Return the area of the triangle. */
	public static double area(double side1, double side2, double side3) {
		
		double s = (side1 + side2 + side3) / 2;
		double area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		return area;
	}
	
}