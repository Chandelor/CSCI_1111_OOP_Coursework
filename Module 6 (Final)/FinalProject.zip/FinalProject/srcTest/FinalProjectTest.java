import static org.junit.Assert.*;
import org.junit.Test;

public class FinalProjectTest {
	int boardHeight = 6;
	int boardWidth = 7;
	int playerCount = 2;
	int piecesInARow = 4;
	int winCondition = 0;
	String useDefault = "yes";
	Player[] testPlayer = new Player[2];
	BoardSpace[][] testBoard = new BoardSpace[boardHeight][boardWidth];
	
	@Test
	public void testGetMode() {
		assertEquals(Game.getMode(), useDefault);
	}

	@Test
	public void testGetWinCondition() {
		assertEquals(Game.getWinCondition(boardHeight, boardWidth), piecesInARow);
	}
	
	@Test
	public void testGetPlayerCount() {
		assertEquals(Game.getPlayerCount(), playerCount);
	}
	
	@Test
	public void testPlayerOrder() {
		assertEquals(Game.playerOrder(playerCount), testPlayer[playerCount]);
	}
	
	@Test
	public void testCheckForWin() {
		for (int n1 = 0; n1 < boardWidth; n1++) {
			for (int n2 = 0; n2 < boardHeight; n2++) {
				testBoard[n2][n1] = new BoardSpace();
			}
			
		}
		
		assertEquals(Game.checkForWin(testPlayer, testBoard, winCondition, piecesInARow, boardWidth, boardHeight), 0);
	}

	@Test
	public void testGetBoardWidth() {
		assertEquals(BoardSpace.getBoardWidth(useDefault), boardWidth);
	}

	@Test
	public void testGetBoardHeight() {
		assertEquals(BoardSpace.getBoardHeight(useDefault), boardHeight);
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCreateBoard() {
		BoardSpace[][] testBoard = new BoardSpace[boardHeight][boardWidth];
		for (int n1 = 0; n1 < boardWidth; n1++) {
			for (int n2 = 0; n2 < boardHeight; n2++) {
				testBoard[n2][n1] = new BoardSpace();
			}
			
		}
		assertEquals(BoardSpace.createBoard(boardWidth, boardHeight), testBoard);
	}
	
}
